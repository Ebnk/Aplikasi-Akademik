<center><br><br><br><br><br><br><br><br>
<img src="assets/images/bsi.jpg" width="200px height="200px" /> <br>
<font Size="6" face="Helvetica">Web Programing</font> <br>
<font Size="6">Universitas Bina Sarana Informatika</font>
</center>
